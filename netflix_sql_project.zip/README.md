# Netflix Data Analysis Using SQL

This project performs a complete end‑to‑end analysis of Netflix content using pure SQL.  
It includes data exploration, trend analysis, content classification, and insight generation.

---

## 📌 **Project Structure**
```
netflix_project/
│── netflix_clean_project.sql     # Full SQL script
│── README.md                     # Project documentation
```

---

## 🚀 **What This Project Covers**

### ✔️ Table creation & schema design  
A clean SQL schema for storing Netflix titles with correct datatypes.

### ✔️ Data cleaning  
Handling missing values and structuring fields for analysis.

### ✔️ Exploratory analysis  
- Count of Movies vs TV Shows  
- Top countries producing Netflix content  
- Most common genres  
- Most frequent content ratings  
- Year‑wise content added trends  
- Top directors  

### ✔️ Content classification (Good vs Bad)
Using keyword matching on descriptions to categorize violent vs non‑violent content.

---

## 📊 **Key SQL Concepts Used**
- `CASE WHEN` logic  
- `GROUP BY` aggregations  
- `ORDER BY` sorting  
- `LIMIT` filters  
- `EXTRACT()` for date analysis  
- `CTE (WITH)` for classification  
- Pattern matching using `ILIKE`  

---

## 📈 **Sample Insights**
- Which genres dominate Netflix  
- How content trends have changed over the years  
- Countries producing the most titles  
- Directors with the most published content  

---

## 🛠️ **Tech Stack**
- SQL (PostgreSQL / MySQL compatible with minor changes)

---

## 📥 How to Use
1. Import the SQL file into your database  
2. Run queries section-wise  
3. Modify filters to explore deeper insights  

---

## 👤 Author
Your Name  
LinkedIn: *Add your link*  
GitHub: *Add your profile link*  
