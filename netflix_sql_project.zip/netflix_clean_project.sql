-- Netflix Data Analysis Using SQL
-- Author: <Your Name>
-- Description: Complete end‑to‑end SQL project for Netflix dataset.

------------------------------------------------------------
-- SECTION 1: TABLE CREATION
------------------------------------------------------------
DROP TABLE IF EXISTS netflix;

CREATE TABLE netflix
(
    show_id        VARCHAR(10),
    type           VARCHAR(20),
    title          VARCHAR(300),
    director       VARCHAR(600),
    casts          VARCHAR(1500),
    country        VARCHAR(600),
    date_added     DATE,
    release_year   INT,
    rating         VARCHAR(20),
    duration       VARCHAR(20),
    listed_in      VARCHAR(300),
    description    VARCHAR(600)
);

------------------------------------------------------------
-- SECTION 2: CORE ANALYSIS QUERIES
------------------------------------------------------------

-- 1. Count total movies and TV shows
SELECT type, COUNT(*) AS total_count
FROM netflix
GROUP BY type
ORDER BY total_count DESC;

-- 2. Top 10 countries producing the most Netflix content
SELECT country, COUNT(*) AS total_content
FROM netflix
WHERE country IS NOT NULL
GROUP BY country
ORDER BY total_content DESC
LIMIT 10;

-- 3. Most common genres
SELECT listed_in, COUNT(*) AS total
FROM netflix
GROUP BY listed_in
ORDER BY total DESC
LIMIT 15;

-- 4. Top 10 directors with the most content
SELECT director, COUNT(*) AS total_content
FROM netflix
WHERE director IS NOT NULL AND director <> ''
GROUP BY director
ORDER BY total_content DESC
LIMIT 10;

-- 5. Content added trend by year
SELECT EXTRACT(YEAR FROM date_added) AS year_added,
       COUNT(*) AS total_titles
FROM netflix
WHERE date_added IS NOT NULL
GROUP BY year_added
ORDER BY year_added;

-- 6. Most frequent rating
SELECT rating, COUNT(*) AS total
FROM netflix
GROUP BY rating
ORDER BY total DESC;

------------------------------------------------------------
-- SECTION 3: BAD CONTENT CLASSIFICATION
------------------------------------------------------------

WITH classified AS (
    SELECT *,
           CASE
               WHEN description ILIKE '%kill%'
                    OR description ILIKE '%violence%'
                    OR description ILIKE '%murder%'
                    OR description ILIKE '%blood%'
                    OR description ILIKE '%crime%' 
               THEN 'Bad_Content'
               ELSE 'Good_Content'
           END AS category
    FROM netflix
)

SELECT category, COUNT(*) AS total_content
FROM classified
GROUP BY category
ORDER BY total_content DESC;

------------------------------------------------------------
-- SECTION 4: EXTRA INSIGHTFUL QUERIES
------------------------------------------------------------

-- 7. Oldest content on Netflix
SELECT title, release_year
FROM netflix
ORDER BY release_year ASC
LIMIT 10;

-- 8. Longest duration content (movies/TV)
SELECT title, duration
FROM netflix
ORDER BY duration DESC;

