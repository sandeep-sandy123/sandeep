# 🌦 Power BI Weather Dashboard

A real-time weather monitoring dashboard built using **Power BI**, **Power Query**, **DAX**, and **API integration**.

## 📌 Features
- Live weather API integration
- Forecast visualization
- AQI details
- Sunrise/Sunset
- Automated refresh
- Clean UI design

## Files Included
- README.md
- API_Query_Code.txt
- DAX_Measures.txt
- Screenshots folder (add your images)
